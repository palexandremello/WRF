export PGI_OBJSUFFIX=o
export NETCDF=C:/NETCDF401
export J=" "

